# zend-console

`Zend\Console` is a component to design and implement console applications in PHP.


- File issues at https://github.com/zendframework/zend-console/issues
- Documentation is at http://framework.zend.com/manual/current/en/index.html#zend-console
