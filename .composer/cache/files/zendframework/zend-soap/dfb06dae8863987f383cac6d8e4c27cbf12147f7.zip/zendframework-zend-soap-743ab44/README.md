# zend-soap

`Zend\Soap` is a component to manage the [SOAP](http://en.wikipedia.org/wiki/SOAP)
protocol in order to design client or server PHP application.


- File issues at https://github.com/zendframework/zend-soap/issues
- Documentation is at http://framework.zend.com/manual/current/en/index.html#zend-soap
