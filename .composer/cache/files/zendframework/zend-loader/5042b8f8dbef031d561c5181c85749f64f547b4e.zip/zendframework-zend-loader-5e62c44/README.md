# zend-loader

`Zend\Loader` provides different strategies for autoloading PHP classes.


- File issues at https://github.com/zendframework/zend-loader/issues
- Documentation is at http://framework.zend.com/manual/current/en/index.html#zend-loader
