# zend-di

`Zend\Di` is an example of an Inversion of Control (IoC) container. IoC containers
are widely used to create object instances that have all dependencies resolved
and injected. Dependency Injection containers are one form of IoC – but not the
only form.


- File issues at https://github.com/zendframework/zend-di/issues
- Documentation is at http://framework.zend.com/manual/current/en/index.html#zend-di
