# zend-serializer

The `Zend\Serializer` component provides an adapter based interface to simply
generate storable representation of PHP types by different facilities, and
recover.


- File issues at https://github.com/zendframework/zend-serializer/issues
- Documentation is at http://framework.zend.com/manual/current/en/index.html#zend-serializer
