# zend-stdlib

`Zend\Stdlib` is a set of components that implements general purpose utility
class for different scopes like:

- array utilities functions;
- hydrators;
- json serialazible interfaces;
- general messaging systems;
- strin wrappers;
- etc


- File issues at https://github.com/zendframework/zend-stdlib/issues
- Documentation is at http://framework.zend.com/manual/current/en/index.html#zend-stdlib
