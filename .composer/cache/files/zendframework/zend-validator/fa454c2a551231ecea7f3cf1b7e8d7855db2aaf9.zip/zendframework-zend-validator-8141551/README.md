# zend-validator

The `Zend\Validator` component provides a set of commonly needed validators. It
also provides a simple validator chaining mechanism by which multiple validators
may be applied to a single datum in a user-defined order.


- File issues at https://github.com/zendframework/zend-validator/issues
- Documentation is at http://framework.zend.com/manual/current/en/index.html#zend-validator
