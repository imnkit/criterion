# zend-log

`Zend\Log` is a component for general purpose logging. It supports multiple log
backends, formatting messages sent to the log, and filtering messages from being
logged.


- File issues at https://github.com/zendframework/zend-log/issues
- Documentation is at http://framework.zend.com/manual/current/en/index.html#zend-log
